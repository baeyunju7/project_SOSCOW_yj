// 지역 데이터
const regionData = {

    충청남도: {
        계룡시 : ["두마면", "엄사면"],
        공주시 : ["검상동","계룡면","동현동","무릉동","반포면",
            "봉정동","사곡면","상왕동","석장리동","소학동","송선동",
            "신기동","신관동","신풍면","쌍신동","오곡동","우성면",
            "웅진동","월미동","월송동","유구읍","의당면","이인면",
            "정안면","주미동","탄천면","태봉동"],
        금산군 : ["군북면","금산읍","금성면","남이면","남일면",
            "복수면","부리면","제원면","진산면","추부면"],
        논산시 : ["가야곡면","강경읍","강산동","광석면","노성면",
            "등화동","별곡면","부적면","상월면","성동면","양촌면",
            "연무읍","연산면","은진면","채운면"],
        당진시 : ["고대면","구룡동","대덕동","대호지면","면천면",
                "사기소동","석문면","송산면","송악읍","순성면","시곡동",
                "신평면","용연동","우강면","우두동","정미면","채운동","합덕읍","행정동"],
        보령시 : ["남포면","내항동","동대동","미산면","성주면","신흑동","오천면",
                  "요암동","웅천읍","주교면","주산면","주포면","천북면","청라면",
                  "청소면","화산동"],
        부여군 : ["구룡면","규암면","남면","내산면","부여읍","석성면","세도면",
                  "양화면","옥산면","외산면","은산면","임천면","장암면","초촌면",
                  "충화면","홍산면"],
        서산시 : ["갈산동","고북면","대산읍","동문동","부석면","성연면","수석동","양대동",
                  "예천동","오남동","온석동","운산면","음암면","인지면","잠홍동","장동","지곡면",
                  "팔봉면","해미면"],
        서천군 : ["기산면","마산면","문산면","비인면","서면","서천읍","시초면","장항읍","종천면",
                 "판교면","한산면","화양면"],
        아산시 : ["도고면","둔포면","득산동","방축동","배미동","배방읍","선장면","송악면","신인동",
                "신창면","실옥동","염치읍","영인면","음봉면","인주면","장존동","초사동","탕정면"],
        예산군 : ["고덕면","광시면","대술면","대흥면","덕산면","봉산면","삽교읍","신암면","신양면",
                "예산읍","오가면","응봉면"],
        천안시 : ["동남구","서북구"],
        청양군 : ["남양면","대치면","목면","비봉면","운곡면","장평면","정산면","청남면","청양읍",
                "화성면"],
        태안군 : ["고남면","근흥면","남면","소원면","안면읍","원북면","이원면","태안읍"],
        홍성군 : ["갈산면","결성면","광천읍","구항면","금마면","서부면","은하면","장곡면","홍동면",
                "홍북면","홍북읍","홍성읍"]
    },

  };

const disinfectionCenters = {
    "충청남도 공주시": " 탄천면 안영리 0044-0012 \n\n 이름: 신평 거점소독시설 \n\n 영업시간: 00:00 ~ 24:00 \n\n 밀집도: 🔴" ,
    "충청남도 계룡시": " 월미동 0307-0018 \n\n 이름: 청소 거점 소독소 \n\n 영업시간: 00:00 ~ 24:00 \n\n 밀집도: 🔴",
    "충청남도 금산군": " 금산읍 신대리 0422-0001 \n\n 이름: 서천군 거점소독시설 \n\n 영업시간: 00:00 ~ 24:00 \n\n 밀집도: 🔴",
    "충청남도 논산시": " 부적면 덕평리 26-1 \n\n 이름: 병천 거점소독시설 \n\n 영업시간: 05:00 ~ 17:00 \n\n 밀집도: 🔴",
    "충청남도 당진시": " 신평면 상오리 1045-0001 \n\n 이름: 성환 거점소독시설 \n\n 영업시간: 05:00 ~ 17:00 \n\n 밀집도: 🟠",
    "충청남도 보령시": " 청소면 신송리0062-0006 \n\n 이름: 탄천 거점소독시설 \n\n 영업시간: 04:00 ~ 16:00 \n\n 밀집도: 🟠",
    "충청남도 부여군": " 석성면 증산리 1137-0003 \n\n 이름: 궁평 거점소독시설 \n\n 영업시간: 00:00 ~ 24:00 \n\n 밀집도: 🔴",
    "충청남도 서산시": " 음암면 문양리 0234 0041 \n\n 이름: 광천 운용리 거점세척소독시설 \n\n 영업시간: 00:00 ~ 24:00 \n\n 밀집도: 🔴",
    "충청남도 서천군": " 마서면 도삼리 0751-0012 \n\n 이름: 이원면 사창리 거점소독소 \n\n 영업시간: 00:00 ~ 24:00 \n\n 밀집도: 🔴",
    "충청남도 아산시": " 도고면 효자리 180-1 \n\n 이름: 목천 거점소독시설 \n\n 영업시간: 04:00 ~ 20:00 \n\n 밀집도: 🟢",
    "충청남도 예산군": " 예산읍 궁평리 0055-0007 \n\n 이름: 궁평 거점세척소독시설 \n\n 영업시간: 00:00 ~ 24:00 \n\n 밀집도: 🟠",
    "충청남도 천안시": " 동남구 목천읍 삼성리 161-6 \n\n 이름: 음암 거점 소독시설 \n\n 영업시간: 00:00 ~ 24:00 \n\n 밀집도: 🟢",
    "충청남도 청양군": " 대치면 대치리 0006-0002 \n\n 이름: 천수만로 거점소독소 \n\n 영업시간: 06:00 ~ 22:00 \n\n 밀집도: 🔴 ",
    "충청남도 태안군": " 남면 당암리 980-0 \n\n 이름: 광천 우시장 거점세척소독시설 \n\n 영업시간: 02:00 ~ 18:00 \n\n 밀집도: 🟢",
    "충청남도 홍성군": " 광천읍 신진리 570-3 \n\n 이름: 홍성읍 거점세척소독시설 \n\n 영업시간: 02:00 ~ 18:00 \n\n 밀집도: 🟢",

    // 추가 데이터...
};





// 대체 지역 설정 (거점 소독장소가 없는 경우)
const alternativeCenters = {
    "충청남도 공주시 월미동": "월미동 0307-0018 청소거점 소독소",
    "충청남도 태안군": "서산시 팔봉면 OOO 소독장",
    // 추가 필요
};

  // 드롭다운 요소 선택
  const doDropdown = document.getElementById("do-dropdown");
  const siDropdown = document.getElementById("si-dropdown");
  const mienDropdown = document.getElementById("mien-dropdown");

  // 도 드롭다운 변경 시
  doDropdown.addEventListener("change", () => {
    const selectedDo = doDropdown.value;
    siDropdown.innerHTML = '<option value="">시</option>';
    mienDropdown.innerHTML = '<option value="">면</option>';

    if (selectedDo && regionData[selectedDo]) {
      Object.keys(regionData[selectedDo]).forEach((si) => {
        const option = document.createElement("option");
        option.value = si;
        option.textContent = si;
        siDropdown.appendChild(option);
      });
    }
  });

  // 시 드롭다운 변경 시
  siDropdown.addEventListener("change", () => {
    const selectedDo = doDropdown.value;
    const selectedSi = siDropdown.value;
    mienDropdown.innerHTML = '<option value="">면</option>';

    if (selectedDo && selectedSi && regionData[selectedDo][selectedSi]) {
      regionData[selectedDo][selectedSi].forEach((mien) => {
        const option = document.createElement("option");
        option.value = mien;
        option.textContent = mien;
        mienDropdown.appendChild(option);
      });
    }
  });

// 면 드롭다운 변경 시
mienDropdown.addEventListener("change", () => {
    const selectedDo = doDropdown.value;
    const selectedSi = siDropdown.value;
    const selectedMien = mienDropdown.value;

    // 기존 면 추가 로직
    if (selectedDo && selectedSi && regionData[selectedDo][selectedSi]) {
        regionData[selectedDo][selectedSi].forEach((mien) => {
            const option = document.createElement("option");
            option.value = mien;
            option.textContent = mien;
            mienDropdown.appendChild(option);
        });
    }

    // 거점 소독장소 찾기
    const selectedLocation = `${selectedDo} ${selectedSi}`;
    let disinfectionCenter = disinfectionCenters[selectedLocation];

    if (!disinfectionCenter) {
        // 해당 지역에 소독장이 없으면 대체 지역 검색
        disinfectionCenter = alternativeCenters[`${selectedDo} ${selectedSi}`] || "근처 거점 소독장소 없음";
    }

    // 결과 표시
    document.getElementById("disinfection-result").innerText = `위치: ${disinfectionCenter}`;
});

function loadDisinfectionCenter(region) {
    document.getElementById('cleanTitle').innerText = `${region} 인근 거점 소독소 안내`;

    fetch(`/kakao/clean_zone?region=${region}`)
        .then(response => response.json())
        .then(data => {
            if (data && data.name) {
                document.getElementById('zoneLocation').innerText = data.location;
                document.getElementById('zoneName').innerText = data.name;
                document.getElementById('zoneTime').innerText = data.time;
                document.getElementById('zoneDensity').innerText = data.density;
                document.getElementById('noZoneData').style.display = 'none';
            } else {
                document.getElementById('zoneLocation').innerText = '-';
                document.getElementById('zoneName').innerText = '-';
                document.getElementById('zoneTime').innerText = '-';
                document.getElementById('zoneDensity').innerText = '-';
                document.getElementById('noZoneData').style.display = 'block';
            }
        })
        .catch(err => console.error(err));
}

// 버튼 클릭 시 기존 chart fetch 이후 소독장 fetch
document.getElementById('loadChartBtn').addEventListener('click', function () {
    const year = document.getElementById('year-dropdown').value;
    const region = document.getElementById('si-dropdown').value;

    if (!year || !region) {
        alert("날짜와 장소를 선택 후 버튼을 눌러주세요.");
        return;
    }

    // ✅ 타이틀도 함께 갱신해주기
    document.getElementById('graphTitle').innerText = `${year}년 ${region} 럼피스킨 예상 발생 추이`;

    // 차트 fetch 및 drawChart 호출
    fetch(`/kakao/total_data/?year=${year}&region=${region}`)
        .then(response => response.json())
        .then(data => {
            drawChart(region, data.values);
        });

    loadDisinfectionCenter(region);  // (지금은 아마 다른 페이지로 옮겼으니 이건 생략됐을 수 있음)
});

// ⭐ 페이지 로드 시 서산시 정보 자동 표시
window.addEventListener('load', function () {
    document.getElementById('graphTitle').innerText = `2024년 서산시 럼피스킨 예상 발생 추이`;
    document.getElementById('cleanTitle').innerText = `서산시 인근 거점 소독소 안내`;
    loadChart('2024', '서산시');
    loadDisinfectionCenter('서산시');
});


// 하버사인 거리계산 함수
function getDistance(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
        Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
}

// 타겟 주소 배열 (예시)
const targetAddresses = ['계룡시', '공주시', '금산군', '논산시', '당진시','보령시','부여군','서산시','서천군','아산시','예산군','천안시','청양군','태안군','홍성군'];

async function calculateSecondRiskArea(centerAddress) {
    const centerCoord = await getCoordinates(centerAddress);
    if (!centerCoord) {
        console.error("중심 좌표 가져오기 실패");
        return;
    }

    const candidates = [];
    for (const target of targetAddresses) {
        if (target === centerAddress) continue; // 선택 지역 제외
        const targetCoord = await getCoordinates(target);
        if (targetCoord) {
            candidates.push({
                region: target,
                distance: getDistance(centerCoord, targetCoord)
            });
        }
    }

    if (candidates.length > 0) {
        const nearest = candidates.sort((a, b) => a.distance - b.distance)[0];
        document.getElementById('second-risk-info').innerText =
            `${nearest.region}`;
    } else {
        document.getElementById('second-risk-info').innerText = `10km 이내 예상 피해지역 없음`;
    }
}

// 버튼 클릭 시 2차 예상 피해지역 계산 호출
document.getElementById('loadChartBtn').addEventListener('click', function() {
    const selectedRegion = document.getElementById('si-dropdown').value;
    const selectedMonth = document.getElementById('month-dropdown').value;
    const selectedYear = document.getElementById('year-dropdown').value;

    if (selectedRegion && selectedYear) {
        getSimulationResult(selectedRegion, selectedMonth, selectedYear);
        calculateSecondRiskArea(selectedRegion);  // 2차 피해지역 계산
        getPredictedCowSum(selectedYear, selectedMonth, selectedRegion); // ✅ 머신러닝 예측 값 가져오기
    } else {
        alert('시군구와 연도를 모두 선택해주세요.');
    }
});


//지연미분방정식 불러오기
function getSimulationResult(regionName, month, year) {
    fetch('/kakao/dde_simulation/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ region: regionName, month: month })
    })
    .then(response => response.json())
    .then(data => {
        console.log(data);
        document.getElementById('region-title').innerText = `${year}년 ${data.month}월 ${data.region} 럼피스킨 전파율`;
        document.getElementById('beta-info').innerText = `전파율: ${data.beta.toFixed(3)}`;
        document.getElementById('risk-index-info').innerText = `평균 대비 ${data.risk_index.toFixed(2)}배`;
        document.getElementById('max-infected').innerText = `예상 발생두수: ${data.max_infected.toFixed(2)}마리`;
    });
}

function getPredictedCowSum(year, month, regionName) {
    fetch('/kakao/predict_cow_sum', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ year: year, month: month, si: regionName })
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('predict-cow').innerText = ` ${data.predict_cow_sum}마리`;
    });
}
