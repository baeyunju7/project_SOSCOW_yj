// Kakao API 키
const apiKey = "d28e9c1d7d001088f76a7453b5db7d9b";

// 지도 초기화
const mapContainer = document.getElementById("map"); // 지도를 표시할 div
const mapOptions = {
    center: new kakao.maps.LatLng(36.5, 127.5), // 기본 중심 좌표
    level: 7 // 확대 레벨
};
const map = new kakao.maps.Map(mapContainer, mapOptions);
let currentMarker = null; // 현재 표시된 마커

// 데이터: 면 단위 지역
const addressData = {

      충청남도: {
          계룡시 : ["두마면", "엄사면"],
          공주시 : ["검상동","계룡면","동현동","무릉동","반포면",
              "봉정동","사곡면","상왕동","석장리동","소학동","송선동",
              "신기동","신관동","신풍면","쌍신동","오곡동","우성면",
              "웅진동","월미동","월송동","유구읍","의당면","이인면",
              "정안면","주미동","탄천면","태봉동"],
          금산군 : ["군북면","금산읍","금성면","남이면","남일면",
              "복수면","부리면","제원면","진산면","추부면"],
          논산시 : ["가야곡면","강경읍","강산동","광석면","노성면",
              "등화동","별곡면","부적면","상월면","성동면","양촌면",
              "연무읍","연산면","은진면","채운면"],
          당진시 : ["고대면","구룡동","대덕동","대호지면","면천면",
                  "사기소동","석문면","송산면","송악읍","순성면","시곡동",
                  "신평면","용연동","우강면","우두동","정미면","채운동","합덕읍","핻정동"],
          보령시 : ["남포면","내항동","동대동","미산면","성주면","신흑동","오천면",
                    "요암동","웅천읍","주교면","주산면","주포면","천북면","청라면",
                    "청소면","화산동"],
          부여군 : ["구룡면","규암면","남면","내산면","부여읍","석성면","세도면",
                    "양화면","옥산면","외산면","은산면","임천면","장암면","초촌면",
                    "충화면","홍산면"],
          서산시 : ["갈산동","고북면","대산읍","동문동","부석면","성연면","수석동","양대동",
                    "예천동","오남동","온석동","운산면","음암면","인지면","잠홍동","장동","지곡면",
                    "팔봉면","해미면"],
          서천군 : ["기산면","마산면","문산면","비인면","서면","서천읍","시초면","장항읍","종천면",
                   "판교면","한산면","화양면"],
          아산시 : ["도고면","둔포면","득산동","방축동","배미동","배방읍","선장면","송악면","신인동",
                  "신창면","실옥동","염치읍","영인면","음봉면","인주면","장존동","초사동","탕정면"],
          예산군 : ["고덕면","광시면","대술면","대흥면","덕산면","봉산면","삽교읍","신암면","신양면",
                  "예산읍","오가면","응봉면"],
          천안시 : ["동남구","서북구"],
          청양군 : ["남양면","대치면","목면","비봉면","운곡면","장평면","정산면","청남면","청양읍",
                  "화성면"],
          태안군 : ["고남면","근흥면","남면","소원면","안면읍","원북면","이원면","태안읍"],
          홍성군 : ["갈산면","결성면","광천읍","구항면","금마면","서부면","은하면","장곡면","홍동면",
                  "홍북면","홍북읍","홍성읍"]
      },

};

// Kakao API를 사용해 지역 좌표를 가져오는 함수
async function getCoordinates(address) {
    const url = `https://dapi.kakao.com/v2/local/search/address.json?query=${encodeURIComponent(address)}`;
    console.log(`주소 요청 : ${address}`);
    try {
        const response = await fetch(url, {
            headers: {
                Authorization: `KakaoAK ${apiKey}`
            }
        });

        const data = await response.json();

        if (data.documents && data.documents.length > 0) {
            const { x: lng, y: lat } = data.documents[0]; // 경도: x, 위도: y
            console.log(`응답 좌표: lat=${lat}, lng=${lng}`);
            return { lat: parseFloat(lat), lng: parseFloat(lng) };
        } else {
            console.error(`주소를 찾을 수 없습니다: ${address}`);
            return null;
        }
    } catch (error) {
        console.error(`API 요청 중 오류가 발생했습니다: ${error}`);
        return null;
    }
};

// 선택된 지역에 마커 생성 및 지도 중심 이동
async function setMarker(province, city, district) {
    const fullAddress = `${province} ${city} ${district}`;
    console.log(`주소 요청: ${fullAddress}`); // 디버깅용 로그
    const coords = await getCoordinates(fullAddress);

    if (coords) {
        const { lat, lng } = coords;

        // 기존 마커 제거
        if (currentMarker) {
            currentMarker.setMap(null);
        }

        // 새 마커 생성
        currentMarker = new kakao.maps.Marker({
            position: new kakao.maps.LatLng(lat, lng),
            map: map
        });

        // 지도 중심 이동
        map.setCenter(new kakao.maps.LatLng(lat, lng));
    } else {
        alert("해당 주소를 찾을 수 없습니다.");
    }
}

// 드롭다운 생성 및 동작 설정
function setupDropdowns() {
    const provinceDropdown = document.getElementById("do-dropdown");
    const cityDropdown = document.getElementById("si-dropdown");
    const districtDropdown = document.getElementById("mien-dropdown");

    // 도 데이터 초기화 및 추가
    provinceDropdown.innerHTML = '<option value="">도</option>' // 기존 옵션 초기화
    for (const province in addressData) {
        const option = document.createElement("option");
        option.value = province;
        option.textContent = province;
        provinceDropdown.appendChild(option);
    }

    // 도 선택 시 시/군 데이터 업데이트
    provinceDropdown.addEventListener("change", () => {
        cityDropdown.innerHTML = '<option value="">시.군.구 선택</option>';
        districtDropdown.innerHTML = '<option value="">읍/면/동 선택</option>';
        const selectedProvince = provinceDropdown.value;

        if (selectedProvince) {
            for (const city in addressData[selectedProvince]) {
                const option = document.createElement("option");
                option.value = city;
                option.textContent = city;
                cityDropdown.appendChild(option);
            }
        }
    });

    // 시/군 선택 시 읍/면/동 데이터 업데이트
    cityDropdown.addEventListener("change", () => {
        districtDropdown.innerHTML = '<option value="">읍/면/동 선택</option>';
        const selectedProvince = provinceDropdown.value;
        const selectedCity = cityDropdown.value;

        if (selectedProvince && selectedCity) {
            for (const district of addressData[selectedProvince][selectedCity]) {
                const option = document.createElement("option");
                option.value = district;
                option.textContent = district;
                districtDropdown.appendChild(option);
            }
        }
    });

    // 읍/면/동 선택 시 마커 생성
    districtDropdown.addEventListener("change", () => {
        const selectedProvince = provinceDropdown.value;
        const selectedCity = cityDropdown.value;
        const selectedDistrict = districtDropdown.value;

        if (selectedProvince && selectedCity && selectedDistrict) {
            setMarker(selectedProvince, selectedCity, selectedDistrict);
        }
    });
}

// 초기화
setupDropdowns();


/*경계선 표시하기*/
let currentPolygon = null; // 현재 표시된 폴리곤

// GeoJSON 데이터를 로드/-75467
async function loadGeoJson() {
    try {
        const response = await fetch('emd.json'); // GeoJSON 파일 로드
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('GeoJSON 데이터를 로드할 수 없습니다:', error);
        return null;
    }
}

// GeoJSON 데이터를 기반으로 폴리곤 생성
async function createPolygonFromGeoJson(districtName) {
    const geoJsonData = await loadGeoJson();

    if (!geoJsonData) {
        alert('GeoJSON 데이터를 로드하지 못했습니다.');
        return;
    }

    const feature = geoJsonData.features.find(f => f.properties.name === districtName);

    if (!feature) {
        alert(`해당 지역의 경계 데이터를 찾을 수 없습니다: ${districtName}`);
        return;
    }

    const coordinates = feature.geometry.coordinates[0];
    const path = coordinates.map(coord => new kakao.maps.LatLng(coord[1], coord[0]));

    if (currentPolygon) {
        currentPolygon.setMap(null);
    }

    currentPolygon = new kakao.maps.Polygon({
        path: path,
        strokeWeight: 3,
        strokeColor: '#FF0000',
        strokeOpacity: 0.8,
        fillColor: '#FFCCCC',
        fillOpacity: 0.4
    });

    currentPolygon.setMap(map);
    map.setCenter(new kakao.maps.LatLng(path[0].getLat(), path[0].getLng()));
}

// 드롭다운 이벤트 연결
districtDropdown.addEventListener("change", () => {
    const selectedDistrict = districtDropdown.value;

    if (selectedDistrict) {
        createPolygonFromGeoJson(selectedDistrict);
    }
});

