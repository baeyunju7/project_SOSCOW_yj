document.addEventListener("DOMContentLoaded", function () {
    const slides = document.querySelectorAll(".carousel-item");
    const indicators = document.querySelectorAll(".carousel-indicators button");
    let currentIndex = 0;
    let interval;

    function showSlide(index) {
        const currentSlide = slides[currentIndex]; // 현재 슬라이드
        const nextSlide = slides[index]; // 다음 슬라이드

        indicators[currentIndex].classList.remove("active");
        indicators[index].classList.add("active");

        // 1️⃣ 현재 슬라이드를 서서히 사라지게 설정
        currentSlide.style.opacity = "0";
        currentSlide.style.zIndex = "0"; // 뒷배경으로 이동

        // 2️⃣ 다음 슬라이드를 서서히 나타나게 설정
        nextSlide.classList.add("active");
        nextSlide.style.opacity = "1";
        nextSlide.style.zIndex = "1"; // 앞으로 가져오기

        currentIndex = index;
    }

    function showNextSlide() {
        showSlide((currentIndex + 1) % slides.length);
    }

    // 자동 슬라이드 실행 (4초 간격, 1.5초 페이드 효과 포함)
    interval = setInterval(showNextSlide, 4000);

    // 인디케이터 클릭 시 해당 슬라이드로 이동
    indicators.forEach((button, index) => {
        button.addEventListener("click", function () {
            clearInterval(interval); // 자동 슬라이드 정지
            showSlide(index);
            interval = setInterval(showNextSlide, 4000); // 다시 자동 시작
        });
    });
});
