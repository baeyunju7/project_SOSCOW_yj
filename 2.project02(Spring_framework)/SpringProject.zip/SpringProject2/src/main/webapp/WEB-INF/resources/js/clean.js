document.addEventListener("DOMContentLoaded", function () {
    let siDropdown = document.getElementById("si-dropdown");

    if (siDropdown) {
        siDropdown.addEventListener("change", function () {
            let selectedSi = siDropdown.value;
            fetchCleanZones(selectedSi);
        });
    }
});

function fetchCleanZones(si) {
    if (!si) {
        document.getElementById("clean_zone_card").innerHTML = "<p>소독소 정보를 불러올 시·군·구를 선택하세요.</p>";
        return;
    }

    fetch(`/chart/clean?si=${si}`)
        .then(response => response.json())
        .then(data => {
            let cleanZoneCard = document.getElementById("clean_zone_card");
            cleanZoneCard.innerHTML = "";  // 기존 내용 초기화

            if (data.length === 0) {
                cleanZoneCard.innerHTML = "<p>해당 지역의 소독소 정보가 없습니다.</p>";
                return;
            }

            let firstItem = data[0];  // 첫 번째 소독장 정보만 표시 (여러 개면 수정 필요)
            cleanZoneCard.innerHTML = `
                <h6 class="text-left">
                    <span style="color: rgb(153,153,153);">위치:</span> ${firstItem.location}
                </h6>
                <h6 class="text-left">
                    <span style="color: rgb(153,153,153);">이름:</span> ${firstItem.name}
                </h6>
                <h6 class="text-left">
                    <span style="color: rgb(153,153,153);">영업시간:</span> ${firstItem.time}
                </h6>
                <h6 class="text-left">
                    <span style="color: rgb(153,153,153);">예상 혼잡도:</span> ${firstItem.density}
                </h6>
            `;
        })
        .catch(error => console.error("Error:", error));
}
