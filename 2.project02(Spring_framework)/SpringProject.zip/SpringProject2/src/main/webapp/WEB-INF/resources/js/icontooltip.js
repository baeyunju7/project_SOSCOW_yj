// 첫 번째 팝업
const iconContainer1 = document.querySelector('.icon-container.popup1');
const popup1 = document.getElementById('popup1');

iconContainer1.addEventListener('click', () => {
    popup1.style.display = 'block';
});

function closePopup1() {
    popup1.style.display = 'none';
}

// 두 번째 팝업
const iconContainer2 = document.querySelector('.icon-container.popup2');
const popup2 = document.getElementById('popup2');

iconContainer2.addEventListener('click', () => {
    popup2.style.display = 'block';
});


const iconContainer3 = document.querySelector('.icon-container.popup3');
const popup3 = document.getElementById('popup3');

iconContainer3.addEventListener('click', () => {
    popup3.style.display = 'block';
});

const iconContainer4 = document.querySelector('.icon-container.popup4');
const popup4 = document.getElementById('popup4');

iconContainer4.addEventListener('click', () => {
    popup4.style.display = 'block';
});

function closePopup2() {
    popup2.style.display = 'none';
}

function openPopup(id) {
  document.getElementById(id).style.display = 'block';
}

function closePopup(id) {
  document.getElementById(id).style.display = 'none';
}

function closePopup3() {
    popup2.style.display = 'none';
}