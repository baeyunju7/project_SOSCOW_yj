document.addEventListener("DOMContentLoaded", function () {
    // 드롭다운 버튼 값 업데이트 기능
    document.querySelectorAll(".dropdown-menu a").forEach(item => {
        item.addEventListener("click", function () {
            let dropdownBtn = this.closest(".dropdown").querySelector(".btn");
            dropdownBtn.textContent = this.textContent;
        });
    });

    // 날짜 선택 버튼 값 유지 기능
    const dateInput = document.getElementById("dateInput");
    dateInput.addEventListener("change", function () {
        document.getElementById("dateButton").textContent = this.value;
    });
});