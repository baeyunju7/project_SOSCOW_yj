(function () {
    document.addEventListener('DOMContentLoaded', () => {
        const headerPlaceholder = document.querySelector('#header-placeholder');

        if (!headerPlaceholder) {
            console.error("#header-placeholder 요소를 찾을 수 없습니다.");
            return;
        }
        
        

        const basePath = "헤더.html"; // 헤더 파일 경로

        fetch(basePath)
            .then((response) => {
                if (!response.ok) {
                    throw new Error("헤더 파일을 로드하는 데 실패했습니다.");
                }
                return response.text();
            })
            .then((data) => {
                headerPlaceholder.innerHTML = data; // 헤더 삽입
                setTimeout(initializeHeaderScripts, 100); // 헤더가 완전히 렌더링된 후 실행
                loadNavbarScript(); // navbar.js 다시 로드
            })
            .catch((error) => {
                console.error("Fetch Error:", error);
            });
    });

    function initializeHeaderScripts() {
        console.log("헤더 스크립트 초기화");

        const menuToggle = document.querySelector('.js-menu-toggle');
        const mobileMenu = document.querySelector('.site-mobile-menu');

        if (!menuToggle || !mobileMenu) {
            console.error("햄버거 메뉴 요소를 찾을 수 없습니다.");
            return;
        }

        menuToggle.addEventListener('click', () => {
            mobileMenu.classList.toggle('active');
            console.log("햄버거 메뉴 클릭됨.");
        });

        // 전역 클릭 감지하여 메뉴 닫기 기능 추가
        document.addEventListener('click', function(event) {
            var specifiedElement = document.querySelector('.js-menu-toggle'); // 햄버거 버튼
            if (!specifiedElement || !menuToggle) {
                console.error("햄버거 메뉴 관련 요소를 찾을 수 없습니다.");
                return;
            }

            var isClickInside = specifiedElement.contains(event.target);
            if (!isClickInside) {
                mobileMenu.classList.remove('active'); // 메뉴 닫기
            }
        });
    }

    function loadNavbarScript() {
        const script = document.createElement("script");
        script.src = "js/navbar.js";  
        script.onload = () => console.log("navbar.js 로드 완료");
        document.body.appendChild(script);
    }
})();



