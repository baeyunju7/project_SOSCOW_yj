document.getElementById("open-calendar").addEventListener("click", function() {
    document.getElementById("date-input").showPicker(); // 강제로 달력 띄우기
});

document.getElementById("date-input").addEventListener("change", function() {
    let selectedDate = this.value;
    if (selectedDate) {
        let dateParts = selectedDate.split("-");
        let formattedDate = `${dateParts[0]}년 ${dateParts[1]}월 ${dateParts[2]}일`;
        document.getElementById("selected-date").innerText = formattedDate;
    }
});

// 시.군.구 가져오기 (Flask API)
fetch("/api/get-si")
    .then(response => response.json())
    .then(data => {
        let siDropdown = document.getElementById("si-dropdown");
        data.forEach(si => {
            let option = document.createElement("option");
            option.value = si;
            option.textContent = si;
            siDropdown.appendChild(option);
        });
    })
    .catch(error => console.error("Error fetching 시.군.구 data:", error));

// 읍.면.동 가져오기 (시 선택 시)
document.getElementById("si-dropdown").addEventListener("change", function() {
    let selectedSi = this.value;
    let mienContainer = document.getElementById("mien-container");

    // 기존 데이터 초기화
    mienContainer.innerHTML = '<h6 class="collapse-header">서비스:</h6>';

    if (selectedSi) {
        fetch(`/api/get-mien?si=${selectedSi}`)
            .then(response => response.json())
            .then(data => {
                data.forEach(mien => {
                    let item = document.createElement("a");
                    item.classList.add("collapse-item");
                    item.href = "#";
                    item.textContent = mien;
                    mienContainer.appendChild(item);
                });
            });
    }
});
