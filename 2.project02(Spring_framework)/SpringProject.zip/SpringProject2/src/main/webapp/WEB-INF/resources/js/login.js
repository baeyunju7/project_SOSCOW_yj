document.addEventListener("DOMContentLoaded", function () {
    const signInTab = document.getElementById("tab-1");
    const signUpTab = document.getElementById("tab-2");

    // 페이지 로드 시 active_tab에 따라 탭 체크
    if (window.location.pathname.includes("/signup")) {
        signUpTab.checked = true;
    } else {
        signInTab.checked = true;
    }

    // 탭 변경 시 URL과 active_tab 업데이트
    signInTab.addEventListener("change", function () {
        history.pushState(null, "", "/login");
        document.getElementById("active-tab-display").innerText = "active_tab: login";
    });

    signUpTab.addEventListener("change", function () {
        history.pushState(null, "", "/signup");
        document.getElementById("active-tab-display").innerText = "active_tab: signup";
    });

    // 뒤로 가기 시 active_tab 유지
    window.addEventListener("popstate", function () {
        if (window.location.pathname.includes("/signup")) {
            signUpTab.checked = true;
            document.getElementById("active-tab-display").innerText = "active_tab: signup";
        } else {
            signInTab.checked = true;
            document.getElementById("active-tab-display").innerText = "active_tab: login";
        }
    });
});
