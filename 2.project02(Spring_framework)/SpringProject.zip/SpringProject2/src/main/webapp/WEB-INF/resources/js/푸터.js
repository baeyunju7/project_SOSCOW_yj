(function () {
    document.addEventListener('DOMContentLoaded', () => {
        const footerPlaceholder = document.querySelector('#footer-placeholder');

        if (!footerPlaceholder) {
            console.error("#footer-placeholder 요소를 찾을 수 없습니다.");
            return;
        }

        
        const basePath = "푸터.html"; 

        fetch(basePath)
            .then((response) => {
                if (!response.ok) {
                    throw new Error("푸터 파일을 로드하는 데 실패했습니다.");
                }
                return response.text();
            })
            .then((data) => {
                // footer.html의 내용을 삽입
                footerPlaceholder.innerHTML = data;
            })
            .catch((error) => {
                console.error("Fetch Error:", error);
            });
    });
})();
