package com.javaEdu.myapp.board.dao;

public class IBoardMapper {

}
