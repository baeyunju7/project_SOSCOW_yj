package com.javaEdu.myapp.member.controller;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.web.bind.annotation.PostMapping;
import com.javaEdu.myapp.member.model.MemberAuthVO;
import com.javaEdu.myapp.member.model.MemberLoginVO;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import com.javaEdu.myapp.member.service.*;
import org.springframework.beans.factory.annotation.Autowired;


@Controller
@RequestMapping("/auth")

public class LoginController {
	
	@Autowired
	private ILoginService loginService;
	
	 @GetMapping("/login")
	    public String showLoginForm(Model model) {
	        model.addAttribute("memberLoginVO", new MemberLoginVO());
	        model.addAttribute("body", "auth/login.jsp");
	        return "base"; // �Ǵ� "auth/login" ������ ����
	    }

	 @PostMapping("/login")
	 public String doLogin(@ModelAttribute("memberLoginVO") MemberLoginVO vo, Model model, HttpSession session) {
	     MemberAuthVO member = loginService.login(vo);

	     if (member != null) {
	         // �α��� ����: ���ǿ� ����� ����
	         session.setAttribute("loginUser", member);
	         return "redirect:/";
	     } else {
	         // �α��� ����: ���� �޽��� + �α��� ������ ����
	         model.addAttribute("loginError", "���̵� �Ǵ� ��й�ȣ�� Ʋ�Ƚ��ϴ�.");
	         model.addAttribute("body", "auth/login.jsp");
	         return "base";
	     }
	 }
}