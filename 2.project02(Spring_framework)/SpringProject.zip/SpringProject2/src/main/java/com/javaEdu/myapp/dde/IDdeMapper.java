package com.javaEdu.myapp.dde;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface IDdeMapper {
	int getCowSum(@Param("year") int year,
								@Param("month") int month,
								@Param("si") String si
			
			);

}
