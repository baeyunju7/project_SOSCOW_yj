package com.javaEdu.myapp.member.service;
import com.javaEdu.myapp.member.model.MemberAuthVO;
import com.javaEdu.myapp.member.model.MemberLoginVO;

public interface ILoginService {
	MemberAuthVO login(MemberLoginVO vo);

}
