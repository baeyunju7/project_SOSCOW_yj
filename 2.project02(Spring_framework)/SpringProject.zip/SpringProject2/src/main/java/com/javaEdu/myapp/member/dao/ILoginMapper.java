package com.javaEdu.myapp.member.dao;
import org.apache.ibatis.annotations.Mapper;
import com.javaEdu.myapp.member.model.MemberAuthVO;
import com.javaEdu.myapp.member.model.MemberLoginVO;

@Mapper
public interface ILoginMapper {
	MemberAuthVO selectMemberByUsernameAndPassword(MemberLoginVO vo);

}
