package com.javaEdu.myapp.board.model;

public class BoardVO {

}
