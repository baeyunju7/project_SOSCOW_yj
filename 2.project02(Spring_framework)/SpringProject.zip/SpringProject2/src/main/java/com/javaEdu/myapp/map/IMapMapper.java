package com.javaEdu.myapp.map;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import com.javaEdu.myapp.map.*;

@Mapper
public interface IMapMapper {
	MapVO selectByRegion(String region);

}
