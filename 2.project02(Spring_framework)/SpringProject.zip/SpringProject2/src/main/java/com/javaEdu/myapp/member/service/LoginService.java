package com.javaEdu.myapp.member.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.javaEdu.myapp.member.dao.ILoginMapper;
import com.javaEdu.myapp.member.model.MemberAuthVO;
import com.javaEdu.myapp.member.model.MemberLoginVO;

@Service
public class LoginService implements ILoginService{
	
	@Autowired
	private ILoginMapper loginMapper;
	
	@Override
	public MemberAuthVO login(MemberLoginVO vo) {
		return loginMapper.selectMemberByUsernameAndPassword(vo);
	}

}
