package com.javaEdu.myapp.graph;
import java.util.List;

public interface IGraphService {
	List<Integer> getCowData(String year, String region);

}
