package com.javaEdu.myapp.member.controller;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.web.bind.annotation.PostMapping;
import com.javaEdu.myapp.member.model.MemberAuthVO;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import com.javaEdu.myapp.member.service.*;
import org.springframework.beans.factory.annotation.Autowired;

@Controller
@RequestMapping("/auth")
public class MemberController {

    @Autowired
    private IMemberService memberService;

    @GetMapping("/signup")
    public String showSignupForm(Model model) {
        model.addAttribute("memberAuthVO", new MemberAuthVO());
        model.addAttribute("body", "auth/signup.jsp");
        return "base"; // �� /WEB-INF/views/auth/signup.jsp
    }
    
    

    @PostMapping("/signup")
    public String doSignup(
    		@Valid @ModelAttribute("memberAuthVO") MemberAuthVO vo,
                           BindingResult result,
                           Model model,
                           HttpSession session) {

        if (result.hasErrors()) {
        	model.addAttribute("body", "auth/signup.jsp");
            return "base";
        }

        if (!vo.getPassword().equals(vo.getPasswordCheck())) {
            model.addAttribute("pwError", "��й�ȣ�� ��ġ���� �ʽ��ϴ�.");
            model.addAttribute("body", "auth/signup.jsp");
            return "auth/signup";
        }

        memberService.join(vo);
        
        session.setAttribute("loginUser", vo);
        return "redirect:/"; // ��: ȸ������ ���� ȭ��
    }
}


