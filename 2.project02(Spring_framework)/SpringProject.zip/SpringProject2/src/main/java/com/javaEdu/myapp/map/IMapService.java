package com.javaEdu.myapp.map;
import com.javaEdu.myapp.map.MapVO;

public interface IMapService {
	MapVO getCleanZoneByRegion(String region);

}
