package com.javaEdu.myapp.graph;

public class GraphVO {
	
	private int year;
	private String si;
	private String month;
	private int cow;
	

	public GraphVO() {}
	
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getSi() {
		return si;
	}
	public void setSi(String si) {
		this.si = si;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public int getCow() {
		return cow;
	}
	public void setCow(int cow) {
		this.cow = cow;
	}

}
