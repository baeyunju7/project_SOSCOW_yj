package com.javaEdu.myapp.graph;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/graph")
public class GraphController {
	
	@Autowired
	private IGraphService graphService;
	
	@GetMapping("")
		public String showGraph() {
		return "graph";
	}
	
	@GetMapping(value="/total_data", produces="application/json; charset=UTF-8")
	@ResponseBody
	public Map<String, Object> getGraph(@RequestParam String year, @RequestParam String region) {
		
		List<Integer> values = graphService.getCowData(year, region);
		
		Map<String, Object> response = new HashMap<>();
		response.put("labels", Arrays.asList("2��", "4��", "6��", "8��", "10��", "12��"));
		response.put("values", values);
		
		return response;
		
	}

}
