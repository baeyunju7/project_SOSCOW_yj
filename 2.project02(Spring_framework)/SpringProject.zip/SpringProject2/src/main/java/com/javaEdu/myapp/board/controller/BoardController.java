package com.javaEdu.myapp.board.controller;

public class BoardController {

}
