package com.javaEdu.myapp.board.service;

public class BoardService {

}
