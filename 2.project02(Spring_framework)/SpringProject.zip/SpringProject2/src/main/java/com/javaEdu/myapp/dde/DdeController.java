package com.javaEdu.myapp.dde;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/dde")
public class DdeController {

    @Autowired
    private IDdeService ddeService;

    @GetMapping("")
    public String showDdePage() {
        return "dde"; 
    }

    @PostMapping("/predict_cow")
    @ResponseBody
    public Map<String, Integer> getCowSum(@RequestBody Map<String, Object> request) {
    	
        int year = (int) request.get("year");
        int month = (int) request.get("month");
        String si = (String) request.get("si");

        int result = ddeService.getCowSum(year, month, si);

        Map<String, Integer> response = new HashMap<>();
        response.put("predict_cow_sum", result);
        return response;
    }
}
