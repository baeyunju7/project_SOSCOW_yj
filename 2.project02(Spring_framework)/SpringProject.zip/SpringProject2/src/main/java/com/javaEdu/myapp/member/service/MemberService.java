package com.javaEdu.myapp.member.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.javaEdu.myapp.member.model.MemberAuthVO;
import com.javaEdu.myapp.member.dao.IMemberMapper;


@Service
public class MemberService implements IMemberService {
	
	@Autowired
	private IMemberMapper memberMapper;
	
	@Override
	public void join(MemberAuthVO vo) {
		memberMapper.insertMember(vo);
	}

}
