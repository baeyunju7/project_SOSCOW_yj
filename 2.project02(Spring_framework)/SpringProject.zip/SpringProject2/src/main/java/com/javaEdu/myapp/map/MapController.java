package com.javaEdu.myapp.map;
import org.springframework.web.bind.annotation.PostMapping;
import com.javaEdu.myapp.member.model.MemberAuthVO;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import com.javaEdu.myapp.member.service.*;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Autowired;

@Controller
@RequestMapping("/map")
public class MapController {

	@Autowired 
	@Qualifier ("mapService")
	private IMapService mapService;

    // 1. map.jsp ������ ����
    @GetMapping("")
    public String showMapPage() {
        return "map"; // /WEB-INF/views/map.jsp
    }

    // 2. fetch�� �񵿱� ��û �޴� clean_zone API
    @GetMapping("/clean_zone")
    @ResponseBody
    public Map<String, Object> getCleanZone(@RequestParam String region) {
        MapVO zone = mapService.getCleanZoneByRegion(region);
        Map<String, Object> result = new HashMap<>();

        if (zone != null) {
            result.put("location", zone.getLocation());
            result.put("name", zone.getName());
            result.put("time", zone.getTime());
            result.put("density", zone.getDensity());
        } else {
        	System.out.println(">> �ش� ������ ���� �ҵ��� ����");
            result.put("error", "�ش� ���� ���� ����");
        }

        return result;
        
    }
    
}

