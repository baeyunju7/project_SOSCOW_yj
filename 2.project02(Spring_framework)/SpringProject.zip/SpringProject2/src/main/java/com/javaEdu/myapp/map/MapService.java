package com.javaEdu.myapp.map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MapService implements IMapService {
	
	@Autowired
	private IMapMapper mapMapper;
	
	@Override
	public MapVO getCleanZoneByRegion(String region) {
		return mapMapper.selectByRegion(region);
	}

}
