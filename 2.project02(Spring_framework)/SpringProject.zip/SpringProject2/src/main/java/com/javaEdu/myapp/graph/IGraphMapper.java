package com.javaEdu.myapp.graph;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import com.javaEdu.myapp.graph.GraphVO;

@Mapper
public interface IGraphMapper {
	List<GraphVO> selectByYearAndRegion(@Param("year") String year, @Param("region") String region);

}
