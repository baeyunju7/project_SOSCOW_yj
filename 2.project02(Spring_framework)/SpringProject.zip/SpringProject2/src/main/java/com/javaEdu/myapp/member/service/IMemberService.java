package com.javaEdu.myapp.member.service;
import com.javaEdu.myapp.member.model.MemberAuthVO;


public interface IMemberService {
	void join(MemberAuthVO vo);

}
