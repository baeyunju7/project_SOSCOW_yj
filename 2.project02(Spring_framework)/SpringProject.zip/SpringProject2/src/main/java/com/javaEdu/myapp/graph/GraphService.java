package com.javaEdu.myapp.graph;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.javaEdu.myapp.graph.GraphVO;

@Service
public class GraphService implements IGraphService {
	
	@Autowired
	private IGraphMapper graphMapper;
	
	@Override
	public List<Integer> getCowData(String year, String region) {
		List<GraphVO> resultList = graphMapper.selectByYearAndRegion(year,region);
		
		Map<Integer, Integer> monthData = new HashMap<>();
		for (GraphVO vo : resultList) {
			String monthStr = vo.getMonth().replace("��", "");
			int month = Integer.parseInt(monthStr);
			monthData.put(month, vo.getCow());
				
		}
		
		List<Integer> values = new ArrayList<>();
		for (int m: Arrays.asList(2,4,6,8,10,12)) {
			values.add(monthData.getOrDefault(m, 0));
		}
		
		return values;
		
				
	}

}
