package com.javaEdu.myapp.dde;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class DdeService implements IDdeService {
	
	@Autowired
	private IDdeMapper ddeMapper;
	
	@Override
	public int getCowSum(int year, int month, String si) {
		return ddeMapper.getCowSum(year, month, si);
	}

}

//Mapperȣ���ؼ� DB����