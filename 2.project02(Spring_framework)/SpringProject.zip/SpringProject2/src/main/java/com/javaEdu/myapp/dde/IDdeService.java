package com.javaEdu.myapp.dde;

public interface IDdeService {
	
	int getCowSum(int year, int month, String si);

}
