package com.javaEdu.myapp.member.dao;
import org.apache.ibatis.annotations.Mapper;
import com.javaEdu.myapp.member.model.MemberAuthVO;

@Mapper
public interface IMemberMapper {
	public void insertMember(MemberAuthVO vo);

}
