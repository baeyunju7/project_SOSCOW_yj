class Addr:

    def __init__(self, name, number, email, address, group):
        self.__name = name
        self.__number = number
        self.__email = email
        self.__address = address    
        self.__group = group

         
    def get_name (self): 
        return self.__name    
    def set_name (self, value): 
        self.name = value

    def get_number(self):
        return self.__number
    def set_number(self, value):
        self.number = value

    def get_email(self):
        return self.__email 
    def set_email(self, value):
        self.__email = value

    def get_address(self):
        return self.__address
    def set_address(self, value):
        self.__address = value

    def get_group(self):
        return self.__group
    def set_group(self, value):
        self.__group = value

    def print_info(self):
        print(f"이름:{self.__name}")
        print(f"번호:{self.__number}")
        print(f"이메일:{self.__email}")
        print(f"주소:{self.__address}")
        print(f"그룹:{self.__group}")