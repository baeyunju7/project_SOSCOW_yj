from coffee_machine import CoffeeMachine
from coin_handler import insert_coin

def main():
    # 커피 머신 인스턴스 생성
    machine = CoffeeMachine()

    while True:
        # 메인 메뉴 출력
        print("1. 주문하기\n2. 재고 확인\n3. 메뉴 추가\n4. 종료")
        choice = int(input("메뉴를 선택해주세요: "))

        if choice == 1:  # 주문하기
            print("== 주문 가능한 메뉴 ==")
            for i, menu_name in enumerate(machine.menu.keys(), start=1):
                print(f"{i}. {menu_name.capitalize()}")  # 메뉴 리스트 출력
            menu_choice = int(input("주문할 메뉴 번호를 입력하세요: "))
            menu_names = list(machine.menu.keys())
            
            if 1 <= menu_choice <= len(menu_names):
                selected_menu = menu_names[menu_choice - 1]
                if machine.check_resources(selected_menu):
                    print("동전을 넣어주세요.")
                    payment = insert_coin()
                    success = machine.process_payment(selected_menu, payment)
                    if success:
                        machine.make_coffee(selected_menu)
                else:
                    print("재료가 부족합니다. 다음에 다시 이용해주세요.")
            else:
                print("잘못된 메뉴 번호입니다. 다시 시도해주세요.")
        
        elif choice == 2:  # 재고 확인
            machine.report()
        
        elif choice == 3:  # 메뉴 추가
            name = input("추가할 메뉴 이름: ").lower()
            water = int(input(f"{name}의 물 사용량(ml): "))
            milk = int(input(f"{name}의 우유 사용량(ml): "))
            coffee = int(input(f"{name}의 커피 사용량(g): "))
            cost = int(input(f"{name}의 가격(원): "))
            machine.add_menu(name, water, milk, coffee, cost)
        
        elif choice == 4:  # 종료
            print("프로그램을 종료합니다.")
            break
        
        else:
            print("잘못된 입력입니다. 다시 선택해주세요.")

if __name__ == "__main__":
    main()
