def insert_coin():
    
    print("동전을 넣으세요. 10원, 50원, 100원, 500원 가능")
    pay = int(input("10원짜리는 몇 개를 넣으시겠습니까? ")) * 10
    pay += int(input("50원짜리는 몇 개를 넣으시겠습니까? ")) * 50
    pay += int(input("100원짜리는 몇 개를 넣으시겠습니까? ")) * 100
    pay += int(input("500원짜리는 몇 개를 넣으시겠습니까? ")) * 500
    return pay