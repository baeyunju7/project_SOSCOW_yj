class CoffeeMachine:
    def __init__(self):
        # 메뉴 정의
        self.menu = {
            "espresso": {"water": 50, "milk": 0, "coffee": 18, "cost": 900},
            "latte": {"water": 200, "milk": 150, "coffee": 24, "cost": 1350},
            "cappuccino": {"water": 250, "milk": 100, "coffee": 24, "cost": 2100},
        }
        # 재고 초기화
        self.resources = {
            "water": 300,
            "milk": 200,
            "coffee": 100,
        }
        self.profit = 0

    def check_resources(self, choice):
        """재료가 충분한지 확인"""
        for ingredient, amount in self.menu[choice].items():
            if ingredient != "cost" and self.resources.get(ingredient, 0) < amount:
                print(f"{ingredient}가 부족합니다.")
                return False
        return True

    def make_coffee(self, choice):
        """재료 차감 및 커피 제조"""
        for ingredient, amount in self.menu[choice].items():
            if ingredient != "cost":
                self.resources[ingredient] -= amount
        print(f"{choice}를 준비 중입니다!")

    def process_payment(self, choice, payment):
        """결제 처리 및 잔돈 반환"""
        cost = self.menu[choice]["cost"]
        if payment >= cost:
            change = payment - cost
            self.profit += cost
            print(f"잔돈 {change}원을 반환합니다.")
            print(f"{choice} 맛있게 드세요!")
            return True
        else:
            print(f"지불 금액이 부족합니다. {cost - payment}원이 더 필요합니다.")
            return False

    def report(self):
        """현재 재고와 수익 출력"""
        print(f"물: {self.resources['water']}ml")
        print(f"우유: {self.resources['milk']}ml")
        print(f"커피: {self.resources['coffee']}g")
        print(f"수익: {self.profit}원")

    def add_menu(self, name, water, milk, coffee, cost):
        """새로운 메뉴 추가"""
        self.menu[name] = {"water": water, "milk": milk, "coffee": coffee, "cost": cost}
        print(f"{name} 메뉴가 추가되었습니다!")