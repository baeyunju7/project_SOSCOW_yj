MENU = {
    "espresso": {
        "ingredients": {
            "water": 50,
            'milk' : 0,
            "coffee": 18,
        },
        "cost": 900,
    },
    "latte": {
        "ingredients": {
            "water": 200,
            "milk": 150,
            "coffee": 24,
        },
        "cost": 1350
    },
    "cappuccino": {
        "ingredients": {
            "water": 250,
            "milk": 100,
            "coffee": 24,
        },
        "cost": 2100,
    }
}

resources = {
    "water": 300,
    "milk": 200,
    "coffee": 100,
}

profit = 0

# 재고 상태보기
def check_resources(choice):
  """재고 계산하기"""
  for ingredient in resources:
    amount = MENU[choice]["ingredients"][ingredient]
    resources[ingredient] = resources[ingredient] - amount
  return resources


def back_resources(choice):
  """재고가 부족해서 판매하지 않았다면 원래 resources로 되돌리기"""
  for ingredient in resources:
    amount = MENU[choice]["ingredients"][ingredient]
    resources[ingredient] = resources[ingredient] + amount
  return resources

def insert_coin():
  """소비자가 동전 넣은 것을 계산하기"""
  print("동전을 넣으세요. 10원, 50원, 100원, 500원 가능")
  pay = int(input("10원짜리는 몇 개를 넣으시겠습니까?")) * 10
  pay += int(input("50원짜리는 몇 개를 넣으시겠습니까?")) * 50
  pay += int(input("100원짜리는 몇 개를 넣으시겠습니까?")) * 100
  pay += int(input("500원짜리는 몇 개를 넣으시겠습니까?")) * 500
  return pay

#금액 확인
def enough_coin(choice, pay_amount):
  """금액이 충분한지 확인하고, 적합한 문구 출력하기
  번 돈이 있다면 총액 계산하기"""
  global profit
  if MENU[choice]["cost"]==pay_amount:
    profit += MENU[choice]["cost"]
    print(f"{choice} 맛있게 드세요!")
  elif MENU[choice]["cost"] < pay_amount:
    refund = pay_amount - MENU[choice]["cost"] 
    profit += MENU[choice]["cost"]
    print(f"잔돈은 {refund}입니다 ")
    print(f"{choice} 맛있게 드세요!")
  else:
    lack = MENU[choice]["cost"] - pay_amount
    print(f"지불 금액이 {lack} 만큼 부족합니다.")


# 커피머신 작동
def coffee_or_no(choice, resources):
  """재고가 충분하다면 커피머신 작동하고, 
  아니라면 커피머신 작동 중지하기"""
  remain_list = []
  if resources['water']>=0 and resources['milk']>=0 and resources['coffee'] >= 0:
    print("동전을 넣어주세요")
    pay_amount = insert_coin()
    enough_coin(choice, pay_amount)
    return True

  else:
    for remain in resources:
      if resources[remain]<0:
        remain_list.append(remain)
    length = len(remain_list)
    if length ==1:
      print(f"지금 {remain_list[0]}가 부족합니다. 다음에 다시 이용해주세요")
    elif length ==2:
      print(f"지금 {remain_list[0]}, {remain_list[1]}가 부족합니다. 다음에 다시 이용해주세요")
    else:
      print(f"지금 {remain_list[0]}, {remain_list[1]}, {remain_list[2]}가 부족합니다. 다음에 다시 이용해주세요")
    resources = back_resources(choice)
    return False

keep_going = True
while keep_going:
  choice = input("무엇을 주문하시겠습니까? 원하는 메뉴를 영어로 입력하세요.\n 에스프레소espresso/라떼latte/카푸치노cappuccino \n")
  if choice == "report":
    print(f"현재 재고량은 물은 {resources['water']} 우유는 {resources['milk']} 커피는 {resources['coffee']}입니다.")
    print(f"커피 머신이 번 돈은 {profit}입니다")
  else:
    resources = check_resources(choice)
    keep_going = coffee_or_no(choice, resources)