import os
from datetime import timedelta
from dotenv import load_dotenv

BASE_DIR = os.path.dirname(__file__)
CHROMA_DB_PATH = os.path.join(BASE_DIR, 'pypy', 'ai_rag', 'chroma_store')
print("BASE_DIR:", BASE_DIR)

load_dotenv()

class Config:
    SQLALCHEMY_DATABASE_URI = "oracle+cx_oracle://scott:tiger@localhost:1521/?service_name=xepdb1"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = "dev"
    PERMANENT_SESSION_LIFETIME = timedelta(hours=3)
    OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
    CHROMA_DB_PATH = CHROMA_DB_PATH
