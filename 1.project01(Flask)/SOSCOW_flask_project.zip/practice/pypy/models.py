from enum import unique
from pypy import db

class Users(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, db.Sequence('users_seq', start=1, increment=1), primary_key = True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(200), unique=True, nullable=False)
    @property
    def is_authenticated(self):
        return True
    @property
    def is_active(self):
        return True
    @property
    def is_anonymous(self):
        return False
    def get_id(self):
        return str(self.id)





class Question(db.Model):
    __tablename__ = 'question'

    id = db.Column(db.Integer, db.Sequence('question_seq', start=1, increment=1),primary_key=True)
    subject = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text(), nullable=False)
    create_date = db.Column(db.DateTime(),nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'),nullable=False)
    user = db.relationship('Users', backref=db.backref('question_set'))
    modify_date = db.Column(db.DateTime(), nullable=True)



class Answer(db.Model):
    __tablename__ = 'answer'
    id = db.Column(db.Integer, db.Sequence('answer_seq', start=1, increment=1),primary_key = True)
    question_id = db.Column(db.Integer, db.ForeignKey('question.id',ondelete='CASCADE'))
    question = db.relationship('Question', backref=db.backref('answer_set'))
    content = db.Column(db.Text(), nullable = False)
    create_date = db.Column(db.DateTime(), nullable = False)
    user = db.relationship('Users', backref=db.backref('answer_set'))
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    modify_date = db.Column(db.DateTime(),nullable=True)




# 거점 소독소
class CleanZone(db.Model):
    __tablename__ = 'clean_zone'
    do = db.Column(db.String(50))
    si = db.Column(db.String(50), primary_key= True)
    location = db.Column(db.String(50), primary_key = True)
    name = db.Column(db.String(50), nullable = False)
    time = db.Column(db.String(50))
    density = db.Column(db.String(50))


# 발생두수 (Y),
class PredictLumpy(db.Model):
    __tablename__ = 'predict_lumpy'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True )
    do = db.Column(db.String(26), nullable=True)
    year = db.Column(db.Integer, nullable=True)
    month = db.Column(db.Integer,nullable=True)
    day = db.Column(db.Integer, nullable=True)
    si = db.Column(db.String(26),nullable=True)
    cow = db.Column(db.Numeric(38, 2), nullable=True)


class YearTotal(db.Model):
    __tablename__ = 'year_total'
    count = db.Column(db.Integer, primary_key=True, autoincrement=True)
    year = db.Column(db.Integer)
    si = db.Column(db.String(26))
    month = db.Column(db.String(26))
    cow = db.Column(db.Integer)