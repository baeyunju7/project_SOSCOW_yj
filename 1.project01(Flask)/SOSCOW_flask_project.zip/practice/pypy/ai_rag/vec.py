# vec.py
# 실행할 때만 문서를 벡터 DB에 등록 (중복 방지 포함)

import os
import json
import chromadb
from sentence_transformers import SentenceTransformer

# 경로 설정
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CHROMA_DB_PATH = os.path.join(BASE_DIR, 'chroma_store')
DATA_DIR = os.path.join(BASE_DIR, 'data')

# 클라이언트 및 컬렉션 설정
chroma_client = chromadb.PersistentClient(path=CHROMA_DB_PATH)
collection = chroma_client.get_or_create_collection(name="lumpy_docs")

# 임베딩 모델 로드
embedder = SentenceTransformer("jhgan/ko-sroberta-multitask")

# 실행할 때만 문서 등록
def register_documents():
    added = 0
    skipped = 0

    for file in os.listdir(DATA_DIR):
        file_path = os.path.join(DATA_DIR, file)
        with open(file_path, "r", encoding="utf-8") as f:
            content_str = f.read().strip()
            if not content_str:
                print(f"빈 파일 건너뜀: {file}")
                continue

            try:
                j = json.loads(content_str)
                content = j["content"]
                doc_id = j["id"]

                # 중복 확인
                existing = collection.get(ids=[doc_id])
                if doc_id in existing["ids"]:
                    print(f"이미 등록된 문서: {doc_id}")
                    skipped += 1
                    continue

                # 임베딩 후 추가
                embedding = embedder.encode(content).tolist()
                collection.add(
                    documents=[content],
                    embeddings=[embedding],
                    ids=[doc_id],
                    metadatas=[{"source": file}]
                )
                print(f"등록 완료: {doc_id}")
                added += 1

            except Exception as e:
                print(f"{file} 처리 중 오류 발생: {e}")

    print(f"\n등록 요약: 추가된 문서 {added}개 / 건너뜀 {skipped}개")


#  직접 실행될 때만 실행
if __name__ == "__main__":
    register_documents()
