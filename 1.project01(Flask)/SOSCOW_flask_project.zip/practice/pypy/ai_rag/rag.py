import os
import json
import pdfplumber
from transformers import AutoTokenizer

pdf_path = "lumpy_action_guid.pdf"
full_text =""
with pdfplumber.open(pdf_path) as pdf:
    for page in pdf.pages:
        full_text += page.extract_text() + "\n"


# 사용할 토크나이저 (한국어 지원 모델)
tokenizer = AutoTokenizer.from_pretrained("skt/kogpt2-base-v2")


#토큰화, 분할
inputs = tokenizer(full_text, return_tensors="pt")
tokens = inputs.input_ids[0].tolist()
chunk_size = 300
chunks = [tokens[i:i+ chunk_size] for i in range(0, len(tokens), chunk_size)]

output_dir = "data"
os.makedirs(output_dir, exist_ok=True)

TITLE_PREFIX = "럼피스킨 자료"
for idx, chunk in enumerate(chunks, 1):
    text_chunk = tokenizer.decode(chunk, skip_special_tokens=True)
    rag_json = {
        "id": f"lumpy{idx}",
        "title": f"{TITLE_PREFIX}({idx})",
        "content": text_chunk.strip()
    }
    with open(os.path.join(output_dir, f"lumpy{idx}.json"), "w", encoding="utf-8")as out_f:json.dump(rag_json, out_f, ensure_ascii=False, indent=2)




