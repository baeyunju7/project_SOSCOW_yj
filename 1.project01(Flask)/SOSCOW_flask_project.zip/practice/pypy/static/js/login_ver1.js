document.getElementById("check-date").addEventListener("click", function() {
    let selectedDate = document.getElementById("date-picker").value;
    document.getElementById("selected-date").innerText = "선택한 날짜: " + selectedDate;
});