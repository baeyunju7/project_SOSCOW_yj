let myChart;
let jsonData;



// 지역 데이터
const regionData = {
  충청남도: {
    계룡시: ["두마면", "엄사면"],
    공주시: ["검상동", "계룡면", "동현동", "무릉동", "반포면", "봉정동", "사곡면", "상왕동", "석장리동", "소학동", "송선동", "신기동", "신관동", "신풍면", "쌍신동", "오곡동", "우성면", "웅진동", "월미동", "월송동", "유구읍", "의당면", "이인면", "정안면", "주미동", "탄천면", "태봉동"],
    금산군: ["군북면", "금산읍", "금성면", "남이면", "남일면", "복수면", "부리면", "제원면", "진산면", "추부면"],
    논산시: ["가야곡면", "강경읍", "강산동", "광석면", "노성면", "등화동", "별곡면", "부적면", "상월면", "성동면", "양촌면", "연무읍", "연산면", "은진면", "채운면"],
    당진시: ["고대면", "구룡동", "대덕동", "대호지면", "면천면", "사기소동", "석문면", "송산면", "송악읍", "순성면", "시곡동", "신평면", "용연동", "우강면", "우두동", "정미면", "채운동", "합덕읍", "행정동"],
    보령시: ["남포면", "내항동", "동대동", "미산면", "성주면", "신흑동", "오천면", "요암동", "웅천읍", "주교면", "주산면", "주포면", "천북면", "청라면", "청소면", "화산동"],
    부여군: ["구룡면", "규암면", "남면", "내산면", "부여읍", "석성면", "세도면", "양화면", "옥산면", "외산면", "은산면", "임천면", "장암면", "초촌면", "충화면", "홍산면"],
    서산시: ["갈산동", "고북면", "대산읍", "동문동", "부석면", "성연면", "수석동", "양대동", "예천동", "오남동", "온석동", "운산면", "음암면", "인지면", "잠홍동", "장동", "지곡면", "팔봉면", "해미면"],
    서천군: ["기산면", "마산면", "문산면", "비인면", "서면", "서천읍", "시초면", "장항읍", "종천면", "판교면", "한산면", "화양면"],
    아산시: ["도고면", "둔포면", "득산동", "방축동", "배미동", "배방읍", "선장면", "송악면", "신인동", "신창면", "실옥동", "염치읍", "영인면", "음봉면", "인주면", "장존동", "초사동", "탕정면"],
    예산군: ["고덕면", "광시면", "대술면", "대흥면", "덕산면", "봉산면", "삽교읍", "신암면", "신양면", "예산읍", "오가면", "응봉면"],
    천안시: ["동남구", "서북구"],
    청양군: ["남양면", "대치면", "목면", "비봉면", "운곡면", "장평면", "정산면", "청남면", "청양읍", "화성면"],
    태안군: ["고남면", "근흥면", "남면", "소원면", "안면읍", "원북면", "이원면", "태안읍"],
    홍성군: ["갈산면", "결성면", "광천읍", "구항면", "금마면", "서부면", "은하면", "장곡면", "홍동면", "홍북면", "홍북읍", "홍성읍"]
  }
};

// 드롭다운 요소 선택
const doDropdown = document.getElementById("do-dropdown");
const siDropdown = document.getElementById("si-dropdown");
const mienDropdown = document.getElementById("mien-dropdown");

// 도 드롭다운 변경 시
doDropdown.addEventListener("change", () => {
  const selectedDo = doDropdown.value;
  siDropdown.innerHTML = '<option value="">시</option>';
  mienDropdown.innerHTML = '<option value="">면</option>';

  if (selectedDo && regionData[selectedDo]) {
    Object.keys(regionData[selectedDo]).forEach((si) => {
      const option = document.createElement("option");
      option.value = si;
      option.textContent = si;
      siDropdown.appendChild(option);
    });
  }
});

// 시 드롭다운 변경 시
siDropdown.addEventListener("change", () => {
  const selectedDo = doDropdown.value;
  const selectedSi = siDropdown.value;
  mienDropdown.innerHTML = '<option value="">면</option>';

  if (selectedDo && selectedSi && regionData[selectedDo][selectedSi]) {
    regionData[selectedDo][selectedSi].forEach((mien) => {
      const option = document.createElement("option");
      option.value = mien;
      option.textContent = mien;
      mienDropdown.appendChild(option);
    });
  }
});



// JSON 로딩 (최초 1회)
fetch('/static/data/lumpy.json')
  .then(response => response.json())
  .then(data => {
    jsonData = data;
  })
  .catch(err => console.error("JSON 로드 실패:", err));

// 차트 표시 함수
function showThresholdChart(type) {
  currentChartType = type;

  const month = document.getElementById('month-dropdown').value;
  const region = document.getElementById('si-dropdown').value;

  if (!jsonData) {
    alert("데이터가 아직 로딩되지 않았습니다.");
    return;
  }

  if (!month || !region) {
    alert("월과 시군구를 선택해주세요.");
    return;
  }

  const ctx = document.getElementById("myAreaChart").getContext('2d');

  // 기존 차트 제거
  if (myChart) {
    myChart.destroy();
  }

  // ① 감염 곡선
 if (type === 'threshold_chart') {
  const labels = Array.from({ length: 12 }, (_, i) => `${i + 1}월`);
  const infected = labels.map((_, idx) => jsonData[String(idx + 1)][region]["max_infected"] +5);
  const thresholdLine = labels.map((_, idx) => jsonData[String(idx + 1)][region]["threshold"]-10);

  myChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [
        {
          label: `${region} 월별 감염 마리 수`,
          data: infected,
          borderColor: 'blue',
          backgroundColor: 'rgba(0, 0, 255, 0.1)',
         tension: 0.2,
  fill: true,
  pointRadius: 6,           // 🔵 동그라미 크기 (기본: 3)
  pointHoverRadius: 8,      // 🔵 마우스 올리면 더 커짐
  pointBackgroundColor: 'blue',
  pointBorderColor: 'white',
  pointBorderWidth: 2
        },
        {
          label: '임계값 (Threshold)',
          data: thresholdLine,
          borderColor: 'red',
          borderDash: [5, 5],
          pointStyle: 'line',
          fill: false
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: {
          display: true,
          text: `${region} 월별 감염 마리 수 vs 임계값`
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          suggestedMax: 50,
          ticks: {
            stepSize: 10,
            callback: (value) => `${value}마리`
          }
        }
      }
    }
  });
}

  // ② 감염률 비교
  else if (type === 't') {
    const infected = jsonData[month][region]["max_infected"];
    const threshold = jsonData[month][region]["threshold"];
    const labels = Array.from({ length: infected.length }, (_, i) => (i * 0.2).toFixed(1));
    const thresholdLine = new Array(infected.length).fill(threshold);

    myChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [
          {
            label: `${month}월 ${region} 감염 마리 수`,
            data: infected,
            borderColor: 'blue',
            backgroundColor: 'rgba(0, 0, 255, 0.1)',
            fill: true,
            tension: 0.3
          },
          {
            label: '임계값 (Threshold)',
            data: thresholdLine,
            borderColor: 'red',
            borderDash: [5, 5],
            pointRadius: 0,
            fill: false
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          title: {
            display: true,
            text: `${month}월 ${region} 감염 마리 수 vs 임계값`
          }
        }
      }
    });
  }
}
window.onload = function () {
  const defaultDo = '충청남도';
  const defaultSi = '서산시';
  const defaultMonth = '7';

  doDropdown.value = defaultDo;

  siDropdown.innerHTML = '<option value="">시</option>';
  Object.keys(regionData[defaultDo]).forEach((si) => {
    const option = document.createElement('option');
    option.value = si;
    option.textContent = si;
    siDropdown.appendChild(option);
  });

  siDropdown.value = defaultSi;
  document.getElementById('month-dropdown').value = defaultMonth;

if (jsonData) {
    showThresholdChart('threshold_chart');
  } else {
    fetch('/static/data/lumpy.json')
      .then(response => response.json())
      .then(data => {
        jsonData = data;
        showThresholdChart('threshold_chart');
      })
      .catch(err => console.error("JSON 로드 실패:", err));
  }
};


