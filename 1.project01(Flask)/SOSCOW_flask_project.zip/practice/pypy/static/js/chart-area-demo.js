// 1. 전역 변수
let myLineChart;

// 2. loadChart 함수 정의
function loadChart(year, region) {
    fetch(`/kakao/total_data/?year=${year}&region=${region}`)
        .then(response => response.json())
        .then(data => {
            if (myLineChart) {
                myLineChart.destroy();
            }

            const ctx = document.getElementById("myAreaChart").getContext('2d');
            myLineChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.labels,   // "2월", "4월", "6월", ...
                    datasets: [{
                        label: `${region} 예상 발생 두수`,
                        lineTension: 0.3,
                        backgroundColor: "rgba(78, 115, 223, 0.05)",
                        borderColor: "rgba(78, 115, 223, 1)",
                        pointRadius: 3,
                        pointBackgroundColor: "rgba(78, 115, 223, 1)",
                        pointBorderColor: "rgba(78, 115, 223, 1)",
                        pointHoverRadius: 3,
                        pointHoverBackgroundColor: "rgba(78, 115, 223, 1)",
                        pointHoverBorderColor: "rgba(78, 115, 223, 1)",
                        pointHitRadius: 10,
                        pointBorderWidth: 2,
                        data: data.values
                    }]
                },
                options: {
                    maintainAspectRatio: false,
                    layout: { padding: { left: 10, right: 25, top: 15, bottom: 0 } },
                    scales: {
                        xAxes: [{ gridLines: { display: false, drawBorder: false } }],
                        yAxes: [{
                            ticks: {
                                min: 0,
                                // data.values 최대값 기반으로 max 동적 설정 가능
                                max: Math.max(...data.values) + 20,
                                stepSize: 20,
                                callback: function (value) { return value; }
                            },


                            gridLines: {
                                color: "rgb(234, 236, 244)",
                                zeroLineColor: "rgb(234, 236, 244)",
                                drawBorder: false,
                                borderDash: [2],
                                zeroLineBorderDash: [2]
                            }
                        }]
                    },

                    tooltips: {
                        backgroundColor: "rgb(255,255,255)",
                        bodyFontColor: "#858796",
                        titleMarginBottom: 20,
                        titleFontColor: '#6e707e',
                        titleFontSize: 14,
                        borderColor: '#dddfeb',
                        borderWidth: 1,
                        xPadding: 15,
                        yPadding: 15,
                        displayColors: false,
                        intersect: false,
                        mode: 'index',
                        caretPadding: 10,
                        callbacks: {
                            label: function (tooltipItem) {
                                return tooltipItem.xLabel + ' 예상 발생 두수: ' + tooltipItem.yLabel;
                            }
                        }
                    }
                }
            });
        })
        .catch(err => console.error(err));
}

// 3. 버튼 클릭 이벤트
document.getElementById('loadChartBtn').addEventListener('click', function() {
    const selectedRegion = document.getElementById('si-dropdown').value;
    const selectedMonth = document.getElementById('month-dropdown').value;
    const selectedYear = document.getElementById('year-dropdown').value;

    if (selectedRegion && selectedYear) {
        getSimulationResult(selectedRegion, selectedMonth, selectedYear);
        calculateSecondRiskArea(selectedRegion);
        getPredictedCowSum(selectedYear, selectedMonth, selectedRegion);

        loadChart(selectedYear, selectedRegion);
        loadDisinfectionCenter(selectedRegion);

        document.getElementById('graphTitle').innerText = `${selectedYear}년 ${selectedRegion} 럼피스킨 발생 예측`;
    } else {
        alert('시군구와 연도, 월을 모두 선택해주세요.');
    }
});

// 페이지 로드 시 서산시 자동 표시 및 초기 실행
window.addEventListener('load', function () {
    const defaultRegion = '서산시';
    const defaultYear = '2024';

    document.getElementById('graphTitle').innerText = `${defaultYear}년 ${defaultRegion} 럼피스킨 발생 예측`;

    loadChart(defaultYear, defaultRegion);
    loadDisinfectionCenter(defaultRegion);
    getSimulationResult(defaultRegion, '1', defaultYear);
    calculateSecondRiskArea(defaultRegion);
    getPredictedCowSum(defaultYear, '1', defaultRegion);
});

