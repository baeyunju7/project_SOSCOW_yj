const sendButton = document.querySelector('.chat-send-btn');
const input = document.querySelector('.chat-input');
const chatOutput = document.querySelector('.chat-output');

// 버튼 클릭 시 전송
sendButton.addEventListener('click', sendMessage);

// 엔터 입력 시 전송
input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { // shift+enter는 줄바꿈
        e.preventDefault();  // 폼 자동 제출 방지
        sendMessage();
    }
});

function sendMessage() {
    const message = input.value.trim();
    if (!message) return;

    fetch('/ai/chatbot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: message })
    })
    .then(response => response.json())
    .then(data => {
        chatOutput.innerHTML += `<div class="align-self-end bg-success text-white p-2 rounded-pill mb-2">${message}</div>`;
        if (data.answer) {
            chatOutput.innerHTML += `<div class="align-self-start bg-light p-2 rounded-pill mb-2">${data.answer}</div>`;
        } else {
            chatOutput.innerHTML += `<div class="align-self-start bg-danger text-white p-2 rounded-pill mb-2">에러: ${data.error}</div>`;
        }
        input.value = '';
        chatOutput.scrollTop = chatOutput.scrollHeight;
    })
    .catch(error => console.error('에러:', error));
}

const llamaButton = document.querySelector('.llama-send-btn');
const llamaInput = document.querySelector('.llama-input');
const llamaOutput = document.querySelector('.llama-output');

// 버튼 클릭 시 전송
llamaButton.addEventListener('click', sendCustom);

// 엔터 입력 시 전송
llamaInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendCustom();
    }
});

function sendCustom() {
    const text = llamaInput.value.trim();
    const mode = "translate";  // 또는 "translate"로 변경 가능

    if (!text) return;

    fetch('/ai/custom', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: text})
    })
    .then(response => response.json())
    .then(data => {
        llamaOutput.innerHTML += `<div class="align-self-end bg-success text-white p-2 rounded-pill mb-2">${text}</div>`;
        if (data.result) {
            llamaOutput.innerHTML += `<div class="align-self-start bg-light p-2 rounded-pill mb-2">${data.result}</div>`;
        } else {
            llamaOutput.innerHTML += `<div class="align-self-start bg-danger text-white p-2 rounded-pill mb-2">에러: ${data.error}</div>`;
        }
        llamaInput.value = '';
        llamaOutput.scrollTop = llamaOutput.scrollHeight;
    })
    .catch(error => console.error('에러:', error));
}
