document.addEventListener("DOMContentLoaded", function () {
    const ctx1 = document.getElementById("myBarChart").getContext("2d");

    const yearData = {
        "2023": { 
            labels: ["서산", "당진", "아산", "홍성", "부여"], 
            data: [713, 580, 450, 280, 147]
        },
        "2024": { 
            labels: ["홍성", "부여", "서산", "예산", "당진"], 
            data: [510, 420, 378, 347, 213]
        },
        "2025": { 
            labels: ["서산", "당진", "홍성", "부여", "예산"], 
            data: [600, 570, 421, 310, 129]
        }
    };

    let predictionChart1 = null;

    function createChart(year) {
        if (predictionChart1 !== null) {
            predictionChart1.destroy();
        }

        predictionChart1 = new Chart(ctx1, {
            type: "bar",
            data: {
                labels: yearData[year].labels,
                datasets: [{
                    label: `${year}년 감염 위험도가 높은 지역`,
                    data: yearData[year].data,
                    backgroundColor: "rgba(78, 115, 223, 0.7)",
                    borderColor: "rgba(78, 115, 223, 1)",
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                layout: {
                    padding: { left: 10, right: 25, top: 25, bottom: 0 }
                },
                scales: {
                    x: {
                        grid: { display: false, drawBorder: false },
                        ticks: { maxTicksLimit: 5 }
                    },
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 100,
                            callback: function (value) { return value + ' 마리'; }
                        },
                        grid: {
                            color: "rgb(234, 236, 244)",
                            zeroLineColor: "rgb(234, 236, 244)",
                            drawBorder: false,
                            borderDash: [2],
                            zeroLineBorderDash: [2]
                        }
                    }
                },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: "rgb(255,255,255)",
                        bodyColor: "#858796",
                        titleColor: '#6e707e',
                        borderColor: '#dddfeb',
                        borderWidth: 1,
                        xPadding: 15,
                        yPadding: 15,
                        displayColors: false,
                        caretPadding: 10,
                        callbacks: {
                            label: function (tooltipItem) {
                                return `예상 발생두수: ${tooltipItem.raw} 마리`;
                            }
                        }
                    }
                }
            }
        });
        document.getElementById('chart-year-text').innerText = ``;

    }

    // 초기 차트
    createChart("2024");

    document.getElementById("year-dropdown").addEventListener("change", function () {
        const selectedYear = this.value;
        if (yearData[selectedYear]) {
            createChart(selectedYear);
        }
    });
});